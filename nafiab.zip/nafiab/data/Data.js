const faqItems = [
    {
      question: "Do I have to be an existing T-Mobile customer?",
    },
    {
      question: "What is a commercial on-line service?",
    },
    {
      question: "24 Hours - Technical Support",
    },
    {
      question: "When do you expect to roll out more markets?",
    },
  ];

const cartArray = [
  {
    id:0,
    name:'Bronze Tier',
    speed:400,
    price:20,
  },
  {
    id:1,
    name:'Silver Tier',
    speed:600,
    price:30,
  },
  {
    id:2,
    name:'Gold Tier',
    speed:800,
    price:40,
  },
]
  
  export {faqItems, cartArray}